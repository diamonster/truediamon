﻿@echo off
reg.exe query "HKU\S-1-5-19">nul 2>&1
if %errorlevel% equ 1 goto UACPrompt
 
C:\Tor\tor.exe --service install -options -f "C:\Tor\data\tor\torrc"
exit /b
 
:UACPrompt
mshta "vbscript:CreateObject("Shell.Application").ShellExecute("%~fs0", "", "", "runas", 1) & Close()"
exit /b
